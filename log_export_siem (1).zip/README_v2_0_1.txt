Forcepoint Web Security Cloud

Requirements for running the log download scripts

The zip file downloaded from the SIEM integration portal page includes:
     log_export_siem.cfg
     log_export_siem_v2_0_1.par
     log_export_siem_v2_0_1.pl
     this ReadMe
     
Both  log_export_siem_v2_0_1.par and log_export_siem_v2_0_1.pl should be 
stored together in the same folder.

The configuration file, log_export_siem.cfg, can be located in a different 
folder, if necessary, but the path to it must then be included as a cfgfile
parameter, as follows:

     log_export_siem_v2_0_1.pl --cfgfile c:/siem/log_export_siem.cfg
	 
Best Practice: Please save configuration file with read only permissions to the owner so that credentials can be secured.
     
In order to run the script, Perl must be installed.  In addition, the
PAR::Packer module has to be manually instaleld if it was not installed in 
chosen Perl distribution.

For Windows:

There are two popular Windows Perl distributions: ActivePerl and Strawberry. 
They can be downloaded from perl.org: https://www.perl.org/get.html

To install PAR-Packer on Strawberry:
- Open Strawberry > CPAN Client
- Run: install PAR::Packer

To install PAR-Packer on ActivePerl:
- Open Windows Command Prompt
- Run: cpan PAR::Packer

For Linux:

Perl is typically installed on Linux distributions. 
If PAR::Packer is not installed, it must be manually installed.

- To install PAR-Packer on Debian:  
sudo apt-get install libpar-packer-perl

- To install PAR-Packer on  Redhat: 
sudo dnf install perl-PAR-Packer


